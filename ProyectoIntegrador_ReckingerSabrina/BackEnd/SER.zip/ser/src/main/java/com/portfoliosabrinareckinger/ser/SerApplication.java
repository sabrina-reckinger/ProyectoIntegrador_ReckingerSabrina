package com.portfoliosabrinareckinger.ser;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SerApplication {

	public static void main(String[] args) {
		SpringApplication.run(SerApplication.class, args);
	}

}
